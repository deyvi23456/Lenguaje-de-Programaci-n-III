﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Actividad3_CRUD.Formularios
{
    public partial class FrmCompra : Form
    {
        public FrmCompra()
        {
            InitializeComponent();
        }

        private void FrmCompra_Load(object sender, EventArgs e)
        {
            CargarClientes();
            CargarProductos();
            Mostrar();
        }
        private void CargarClientes()
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query = "SELECT dni, nombre + ' ' + apellidos AS nombreCompleto FROM Clientes";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                // Agregamos una fila especial "Todos" al principio
                DataRow filaTodos = dt.NewRow();
                filaTodos["dni"] = 0;
                filaTodos["nombreCompleto"] = "-- Todos --";
                dt.Rows.InsertAt(filaTodos, 0);

                cboCliente.DataSource = dt;
                cboCliente.DisplayMember = "nombreCompleto";
                cboCliente.ValueMember = "dni";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar clientes: " + ex.Message);
            }

        }

        private void CargarProductos()
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query = "SELECT codigo, nombre FROM Productos";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                // Agregamos una fila especial "Todos" al principio
                DataRow filaTodos = dt.NewRow();
                filaTodos["codigo"] = 0;
                filaTodos["nombre"] = "-- Todos --";
                dt.Rows.InsertAt(filaTodos, 0);

                cboProducto.DataSource = dt;
                cboProducto.DisplayMember = "nombre";
                cboProducto.ValueMember = "codigo";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar productos: " + ex.Message);
            }
        }

        // CONSULTA
        private void btnMostrar_Click(object sender, EventArgs e)
        {
            Mostrar();
        }

        private void Mostrar()
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query = @"SELECT c.nombre + ' ' + c.apellidos AS Cliente, 
                                     p.nombre AS Producto, 
                                     p.precio AS Precio
                              FROM Compras cp
                              INNER JOIN Clientes c ON cp.dniCliente = c.dni
                              INNER JOIN Productos p ON cp.codProducto = p.codigo";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvCompras.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al mostrar: " + ex.Message);
            }
        }

 
        // ALTA
        private void btnAgregar_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query = "INSERT INTO Compras (dniCliente, codProducto) VALUES (@dni, @codigo)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@dni", cboCliente.SelectedValue);
                cmd.Parameters.AddWithValue("@codigo", cboProducto.SelectedValue);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("La compra fue registrada exitosamente");
                Mostrar();
            }
            catch (Exception ex)
            {
                // Si el cliente ya compró antes ese mismo producto, la llave
                // primaria compuesta no deja repetir la combinación.
                MessageBox.Show("Error al agregar (¿ya existe esa combinación cliente-producto?): " + ex.Message);
            }
        }
        //CONSULTAR
        private void btnMostrar_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();

                int dniSeleccionado = Convert.ToInt32(cboCliente.SelectedValue);
                int codigoSeleccionado = Convert.ToInt32(cboProducto.SelectedValue);

                string query = @"SELECT c.dni, c.nombre + ' ' + c.apellidos AS Cliente, 
                                 p.codigo, p.nombre AS Producto, 
                                 p.precio AS Precio
                          FROM Compras cp
                          INNER JOIN Clientes c ON cp.dniCliente = c.dni
                          INNER JOIN Productos p ON cp.codProducto = p.codigo
                          WHERE (@dni = 0 OR c.dni = @dni)
                            AND (@codigo = 0 OR p.codigo = @codigo)";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@dni", dniSeleccionado);
                cmd.Parameters.AddWithValue("@codigo", codigoSeleccionado);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                // Ocultamos las columnas dni y codigo (solo las usamos para el filtro, no para mostrar)
                dgvCompras.DataSource = dt;
                dgvCompras.Columns["dni"].Visible = false;
                dgvCompras.Columns["codigo"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al mostrar: " + ex.Message);
            }
        }
        // BAJA (usa las DOS partes de la llave compuesta)
        private void btnEliminar_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query = "DELETE FROM Compras WHERE dniCliente=@dni AND codProducto=@codigo";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@dni", cboCliente.SelectedValue);
                cmd.Parameters.AddWithValue("@codigo", cboProducto.SelectedValue);

                con.Open();
                int filas = cmd.ExecuteNonQuery();
                con.Close();

                if (filas > 0)
                    MessageBox.Show("La compra fue eliminada exitosamente");
                else
                    MessageBox.Show("No se encontró esa combinación cliente-producto");

                Mostrar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar: " + ex.Message);
            }
        }

        private void btnRegresar_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

