﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad3_CRUD.Formularios
{
    public partial class FrmProductosCaballeros : Form
    {
        public FrmProductosCaballeros()
        {
            InitializeComponent();
        }

        private void FrmProductosCaballeros_Load(object sender, EventArgs e)
        {
            // Llenar tallas 21 a 27 con medias tallas
            for (double talla = 21; talla <= 27; talla += 0.5)
            {
                clbTallas.Items.Add(talla.ToString("0.#"));
            }

            CargarCatalogo();
        }
        private void CargarCatalogo()
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query = "SELECT codigo AS Código, nombre AS Nombre, precio AS Precio FROM Productos";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvCatalogo.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar catálogo: " + ex.Message);
            }
        }
    }
}
