﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Actividad3_CRUD.Formularios
{
    public partial class FrmProveedor : Form
    {
        public FrmProveedor()
        {
            InitializeComponent();
        }

        private void FrmProveedor_Load(object sender, EventArgs e)
        {
            Mostrar();
        }

        // ALTA
        private void btnAgregar_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query = "INSERT INTO Proveedores (nombre, direccion) VALUES (@nombre, @direccion)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@nombre", txtNombre.Text);
                cmd.Parameters.AddWithValue("@direccion", txtDireccion.Text);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("El proveedor fue agregado exitosamente");
                LimpiarCampos();
                Mostrar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al agregar: " + ex.Message);
            }
        }
        // MODIFICACIÓN
        private void btnModificar_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query = "UPDATE Proveedores SET nombre=@nombre, direccion=@direccion WHERE nif=@nif";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@nombre", txtNombre.Text);
                cmd.Parameters.AddWithValue("@direccion", txtDireccion.Text);
                cmd.Parameters.AddWithValue("@nif", txtNif.Text);

                con.Open();
                int filas = cmd.ExecuteNonQuery();
                con.Close();

                if (filas > 0)
                    MessageBox.Show("El proveedor fue modificado exitosamente");
                else
                    MessageBox.Show("No se encontró el NIF indicado");

                LimpiarCampos();
                Mostrar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al modificar: " + ex.Message);
            }
        }
        // BAJA
        private void btnEliminar_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query = "DELETE FROM Proveedores WHERE nif=@nif";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@nif", txtNif.Text);

                con.Open();
                int filas = cmd.ExecuteNonQuery();
                con.Close();

                if (filas > 0)
                    MessageBox.Show("El proveedor fue eliminado exitosamente");
                else
                    MessageBox.Show("No se encontró el NIF indicado");

                LimpiarCampos();
                Mostrar();
            }
            catch (Exception ex)
            {
                // Si el proveedor tiene productos relacionados, la base de datos
                // no dejará borrarlo por la llave foránea. Este mensaje lo explica.
                MessageBox.Show("Error al eliminar (puede que tenga productos asociados): " + ex.Message);
            }
        }

        private void btnMostrar_Click_1(object sender, EventArgs e)
        {
            Mostrar();
        }
        // CONSULTA
        private void Mostrar()
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query;
                SqlCommand cmd;

                if (string.IsNullOrWhiteSpace(txtNif.Text))
                {
                    // Sin nada escrito -> muestra TODOS los proveedores
                    query = "SELECT nif AS NIF, nombre AS Nombre, direccion AS Dirección FROM Proveedores";
                    cmd = new SqlCommand(query, con);
                }
                else
                {
                    // Con un NIF escrito -> muestra SOLO ese proveedor
                    query = "SELECT nif AS NIF, nombre AS Nombre, direccion AS Dirección FROM Proveedores WHERE nif = @nif";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@nif", txtNif.Text);
                }

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvProveedores.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al mostrar: " + ex.Message);
            }

        }
        // REGRESAR
        private void btnRegresar_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
        private void LimpiarCampos()
        {
            txtNif.Clear();
            txtNombre.Clear();
            txtDireccion.Clear();
        }
        // Clic en fila -> cargar datos en los campos
        private void dgvProveedores_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow fila = dgvProveedores.Rows[e.RowIndex];
                txtNif.Text = fila.Cells["NIF"].Value.ToString();
                txtNombre.Text = fila.Cells["Nombre"].Value.ToString();
                txtDireccion.Text = fila.Cells["Dirección"].Value.ToString();
            }
        }
    }
}