﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad3_CRUD.Formularios
{
    public partial class FrmMensaje : Form
    {
        public FrmMensaje(string titulo, string mensaje)
        {
            InitializeComponent();
            this.Text = titulo;
            txtMensaje.Text = mensaje;
            txtMensaje.ReadOnly = true;

            // Quita la selección azul del texto
            txtMensaje.SelectionStart = 0;
            txtMensaje.SelectionLength = 0;
        }
    }
}
