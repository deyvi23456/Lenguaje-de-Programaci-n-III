﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Actividad3_CRUD.Formularios
{
    public partial class FrmProducto : Form
    {
        public FrmProducto()
        {
            InitializeComponent();
        }

        private void FrmProducto_Load(object sender, EventArgs e)
        {
            CargarProveedores();
            Mostrar();
        }
        private void CargarProveedores()
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query = "SELECT nif, nombre FROM Proveedores";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                cboProveedor.DataSource = dt;
                cboProveedor.DisplayMember = "nombre"; // lo que VE el usuario
                cboProveedor.ValueMember = "nif";       // lo que se GUARDA de verdad
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar proveedores: " + ex.Message);
            }
        }

        // ALTA
        private void btnAgregar_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query = "INSERT INTO Productos (nombre, precio, nifProveedor) VALUES (@nombre, @precio, @nif)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@nombre", txtNombre.Text);
                cmd.Parameters.AddWithValue("@precio", Convert.ToDecimal(txtPrecio.Text));
                cmd.Parameters.AddWithValue("@nif", cboProveedor.SelectedValue);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("El producto fue agregado exitosamente");
                LimpiarCampos();
                Mostrar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al agregar: " + ex.Message);
            }
        }
        // MODIFICACIÓN
        private void btnModificar_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query = "UPDATE Productos SET nombre=@nombre, precio=@precio, nifProveedor=@nif WHERE codigo=@codigo";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@nombre", txtNombre.Text);
                cmd.Parameters.AddWithValue("@precio", Convert.ToDecimal(txtPrecio.Text));
                cmd.Parameters.AddWithValue("@nif", cboProveedor.SelectedValue);
                cmd.Parameters.AddWithValue("@codigo", txtCodigo.Text);

                con.Open();
                int filas = cmd.ExecuteNonQuery();
                con.Close();

                if (filas > 0)
                    MessageBox.Show("El producto fue modificado exitosamente");
                else
                    MessageBox.Show("No se encontró el código indicado");

                LimpiarCampos();
                Mostrar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al modificar: " + ex.Message);
            }
        }
        // BAJA
        private void btnEliminar_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query = "DELETE FROM Productos WHERE codigo=@codigo";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@codigo", txtCodigo.Text);

                con.Open();
                int filas = cmd.ExecuteNonQuery();
                con.Close();

                if (filas > 0)
                    MessageBox.Show("El producto fue eliminado exitosamente");
                else
                    MessageBox.Show("No se encontró el código indicado");

                LimpiarCampos();
                Mostrar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se puede eliminar este producto porque tiene compras registradas.\n" +
                         "Elimine primero las compras asociadas a este producto si desea continuar.");
            }
        }

        private void btnMostrar_Click_1(object sender, EventArgs e)
        {
            Mostrar();
        }
        // CONSULTA
        private void Mostrar()
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query;
                SqlCommand cmd;

                if (string.IsNullOrWhiteSpace(txtCodigo.Text))
                {
                    // Sin nada escrito -> muestra TODOS los productos
                    query = @"SELECT p.codigo AS Código, p.nombre AS Nombre, p.precio AS Precio, 
                             pr.nombre AS Proveedor
                      FROM Productos p
                      INNER JOIN Proveedores pr ON p.nifProveedor = pr.nif";
                    cmd = new SqlCommand(query, con);
                }
                else
                {
                    // Con un código escrito -> muestra SOLO ese producto
                    query = @"SELECT p.codigo AS Código, p.nombre AS Nombre, p.precio AS Precio, 
                             pr.nombre AS Proveedor
                      FROM Productos p
                      INNER JOIN Proveedores pr ON p.nifProveedor = pr.nif
                      WHERE p.codigo = @codigo";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@codigo", txtCodigo.Text);
                }

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvProductos.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al mostrar: " + ex.Message);
            }
        }
        // REGRESAR
        private void btnRegresar_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
        private void LimpiarCampos()
        {
            txtCodigo.Clear();
            txtNombre.Clear();
            txtPrecio.Clear();
        }

        private void dgvProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow fila = dgvProductos.Rows[e.RowIndex];
                txtCodigo.Text = fila.Cells["Código"].Value.ToString();
                txtNombre.Text = fila.Cells["Nombre"].Value.ToString();
                txtPrecio.Text = fila.Cells["Precio"].Value.ToString();
            }
        }
    }
}
