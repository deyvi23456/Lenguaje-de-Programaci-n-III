﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad3_CRUD.Formularios
{
    public partial class FrmPassword : Form
    {
        public bool AccesoConcedido { get; private set; }

        public FrmPassword()
        {
            InitializeComponent();
            AccesoConcedido = false;
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            if (txtPassword.Text == "1234")
            {
                AccesoConcedido = true;
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("Contraseña incorrecta");
                txtPassword.Clear();
            }
        }
    }
}