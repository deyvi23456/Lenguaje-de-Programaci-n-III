﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Actividad3_CRUD.Formularios
{
    public partial class FrmCliente : Form
    {
        public FrmCliente()
        {
            InitializeComponent();
        }

        private void FrmCliente_Load(object sender, EventArgs e)
        {
            dtpFechaNac.Format = DateTimePickerFormat.Custom;
            dtpFechaNac.CustomFormat = "dd/MM/yyyy";
            Mostrar();
        }
        // ALTA (Agregar)
        private void btnAgregar_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query = "INSERT INTO Clientes (nombre, apellidos, fechaNac, tfno) VALUES (@nombre, @apellidos, @fechaNac, @tfno)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@nombre", txtNombre.Text);
                cmd.Parameters.AddWithValue("@apellidos", txtApellidos.Text);
                cmd.Parameters.AddWithValue("@fechaNac", dtpFechaNac.Value);
                cmd.Parameters.AddWithValue("@tfno", txtTelefono.Text);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("El cliente fue agregado exitosamente");
                LimpiarCampos();
                Mostrar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al agregar: " + ex.Message);
            }
        }
        // MODIFICACIÓN
        private void btnModificar_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query = "UPDATE Clientes SET nombre=@nombre, apellidos=@apellidos, fechaNac=@fechaNac, tfno=@tfno WHERE dni=@dni";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@nombre", txtNombre.Text);
                cmd.Parameters.AddWithValue("@apellidos", txtApellidos.Text);
                cmd.Parameters.AddWithValue("@fechaNac", dtpFechaNac.Value);
                cmd.Parameters.AddWithValue("@tfno", txtTelefono.Text);
                cmd.Parameters.AddWithValue("@dni", txtDni.Text);

                con.Open();
                int filas = cmd.ExecuteNonQuery();
                con.Close();

                if (filas > 0)
                    MessageBox.Show("El cliente fue modificado exitosamente");
                else
                    MessageBox.Show("No se encontró el DNI indicado");

                LimpiarCampos();
                Mostrar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al modificar: " + ex.Message);
            }
        }
        // BAJA (Eliminar)
        private void btnEliminar_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query = "DELETE FROM Clientes WHERE dni=@dni";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@dni", txtDni.Text);

                con.Open();
                int filas = cmd.ExecuteNonQuery();
                con.Close();

                if (filas > 0)
                    MessageBox.Show("El cliente fue eliminado exitosamente");
                else
                    MessageBox.Show("No se encontró el DNI indicado");

                LimpiarCampos();
                Mostrar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se puede eliminar este cliente porque tiene compras registradas.\n" +
                    "Elimine primero sus compras asociadas, o conserve el registro del cliente.");
            }
        }
        // CONSULTA (Mostrar)
        private void btnMostrar_Click_1(object sender, EventArgs e)
        {
            Mostrar();
        }
        private void Mostrar()
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                string query;
                SqlCommand cmd;

                if (string.IsNullOrWhiteSpace(txtDni.Text))
                {
                    // Si no escribiste nada, muestra TODOS los clientes
                    query = "SELECT dni AS DNI, nombre AS Nombre, apellidos AS Apellidos, fechaNac AS 'Fecha Nac.', tfno AS Teléfono FROM Clientes";
                    cmd = new SqlCommand(query, con);
                }
                else
                {
                    // Si escribiste un DNI, muestra SOLO ese cliente
                    query = "SELECT dni AS DNI, nombre AS Nombre, apellidos AS Apellidos, fechaNac AS 'Fecha Nac.', tfno AS Teléfono FROM Clientes WHERE dni = @dni";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@dni", txtDni.Text);
                }

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvClientes.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al mostrar: " + ex.Message);
            }
        }
        // REGRESAR
        private void btnRegresar_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
        private void LimpiarCampos()
        {
            txtDni.Clear();
            txtNombre.Clear();
            txtApellidos.Clear();
            txtTelefono.Clear();
            dtpFechaNac.Value = DateTime.Now;
        }
        // Al hacer clic en una fila de la tabla, cargar los datos en los campos
        private void dgvClientes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow fila = dgvClientes.Rows[e.RowIndex];
                txtDni.Text = fila.Cells["DNI"].Value.ToString();
                txtNombre.Text = fila.Cells["Nombre"].Value.ToString();
                txtApellidos.Text = fila.Cells["Apellidos"].Value.ToString();
                txtTelefono.Text = fila.Cells["Teléfono"].Value.ToString();
                dtpFechaNac.Value = Convert.ToDateTime(fila.Cells["Fecha Nac."].Value);
            }
        }
    }
    
}

