﻿using System.Data.SqlClient;

public class Conexion
{
    // Cambia "TU_SERVIDOR" por el nombre de tu servidor de SQL Server
    // Ejemplo típico: "DESKTOP-ABC123\SQLEXPRESS" o solo "localhost"
    private static string cadena =
        @"Data Source=localhost;Initial Catalog=ZapateriaUMI;Integrated Security=True";

    public static SqlConnection ObtenerConexion()
    {
        return new SqlConnection(cadena);
    }
}