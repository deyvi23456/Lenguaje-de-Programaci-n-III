﻿using Actividad3_CRUD.Formularios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad3_CRUD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
         private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = Conexion.ObtenerConexion();
                con.Open();
                MessageBox.Show("Conexión exitosa a la base de datos");
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error de conexión: " + ex.Message);
            }
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void mensajeDeBienvenidaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmMensaje f = new FrmMensaje("Bienvenida:",
               "Bienvenido a la tienda en línea ZAPATERÍA UMI, donde podrá encontrar todo lo que usted necesita y si no lo encuentra se lo conseguimos. Somos su mejor opción hoy y siempre.");
            f.ShowDialog();
        }

        private void quiénesSomosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmMensaje f = new FrmMensaje("¿Quiénes Somos?:",
               "Somos una empresa méxicana,  que trata de apoyar al comercio mexicano, todos nuestros productos son 100% mexicanos, por que creemos en nosotros y por que sabemos que podemos.");
            f.ShowDialog();
        }

        private void misiónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmMensaje f = new FrmMensaje("MISION:",
               "Nuestra mision es darnos a conocer a nivel nacional y lograr el objetivo de que todos los mexicanos utilicen productos mexicanos, que abramos los ojos y veamos que no por que el producto sea de otro pais, signifique que es mejor.");
            f.ShowDialog();
        }

        private void visiónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmMensaje f = new FrmMensaje("VISION:",
               "Nuestra vision es que una vez que nos encontremos a nivel nacional, buscaremos el mercado internacional y llevaremos el nombre de nuestro producto, de nuestro pais, a todo el mundo para que sepan de lo que somos capaces.");
            f.ShowDialog();
        }

        private void damasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmProductosDamas f = new FrmProductosDamas();
            f.ShowDialog();
        }

        private void caballerosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmProductosCaballeros f = new FrmProductosCaballeros();
            f.ShowDialog();
        }

        private void clienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmPassword pwd = new FrmPassword();
            if (pwd.ShowDialog() == DialogResult.OK && pwd.AccesoConcedido)
            {
                FrmCliente f = new FrmCliente();
                f.ShowDialog();
            }
        }

        private void proveedorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmPassword pwd = new FrmPassword();
            if (pwd.ShowDialog() == DialogResult.OK && pwd.AccesoConcedido)
            {
                FrmProveedor f = new FrmProveedor();
                f.ShowDialog();
            }
        }

        private void productoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmPassword pwd = new FrmPassword();
            if (pwd.ShowDialog() == DialogResult.OK && pwd.AccesoConcedido)
            {
                FrmProducto f = new FrmProducto();
                f.ShowDialog();
            }
        }

        private void comprasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmCompra f = new FrmCompra();
            f.ShowDialog();
        }
    }  
}
