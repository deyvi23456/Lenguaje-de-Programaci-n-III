/* Creando la base de datos*/
CREATE DATABASE ZapateriaUMI;

/*Utilizando la base de datos*/
USE ZapateriaUMI;

/*Creando la tabla Proveedores*/
CREATE TABLE Proveedores (
    nif INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    direccion VARCHAR(200) NOT NULL
);
/*Creando la tabla Productos*/
CREATE TABLE Productos (
    codigo INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    nifProveedor INT NOT NULL,
    FOREIGN KEY (nifProveedor) REFERENCES Proveedores(nif)
);
/*Creando la tabla Clientes*/
CREATE TABLE Clientes (
    dni INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    fechaNac DATE NOT NULL,
    tfno VARCHAR(20) NOT NULL
);
/*Creando la tabla Compras*/
CREATE TABLE Compras (
    dniCliente INT NOT NULL,
    codProducto INT NOT NULL,
    CONSTRAINT PK_Compras PRIMARY KEY (dniCliente, codProducto),
    FOREIGN KEY (dniCliente) REFERENCES Clientes(dni),
    FOREIGN KEY (codProducto) REFERENCES Productos(codigo)
);

SELECT * FROM Proveedores;
SELECT * FROM Productos;
SELECT * FROM Clientes;
SELECT * FROM Compras;


/*Ingresando datos a la tabla Proveedores*/
INSERT INTO Proveedores (nombre, direccion) VALUES
('Calzado Mexicano S.A.', 'Av. Reforma 123, CDMX'),
('Zapatos del Norte', 'Blvd. Industrial 45, Monterrey'),
('Cueros y Suelas UMI', 'Calle Artesanos 78, León, Guanajuato');

/*Ingresando datos a la tabla Clientes*/
INSERT INTO Clientes (nombre, apellidos, fechaNac, tfno) VALUES
('María', 'González Pérez', '1995-03-14', '6671234567'),
('Juan', 'Ramírez López', '1988-07-22', '6679876543'),
('Ana', 'Martínez Cruz', '2000-11-05', '6675551234'),
('Carlos', 'Sánchez Ibarra', '1992-01-30', '6674443322');

/*Ingresando datos a la tabla Productos*/
INSERT INTO Productos (nombre, precio, nifProveedor) VALUES
('Zapato casual dama talla 24', 599.00, 1),
('Tenis deportivo caballero talla 26', 749.50, 2),
('Bota de piel dama talla 23', 899.00, 3),
('Mocasín caballero talla 27', 650.00, 1),
('Sandalia dama talla 22', 350.00, 2),
('Zapato formal caballero talla 25', 1050.00, 3);

/*Ingresando datos a la tabla Compras*/
INSERT INTO Compras (dniCliente, codProducto) VALUES
(1, 1),
(1, 3),
(2, 2),
(3, 4),
(4, 5),
(4, 6);