namespace Actividad2
{
    partial class FormInformacionPersonal
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormInformacionPersonal));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabDatosPersonales = new System.Windows.Forms.TabPage();
            this.lblNombre = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.lblApellido = new System.Windows.Forms.Label();
            this.txtApellido = new System.Windows.Forms.TextBox();
            this.lblDireccion = new System.Windows.Forms.Label();
            this.txtDireccion = new System.Windows.Forms.TextBox();
            this.lblCiudad = new System.Windows.Forms.Label();
            this.txtCiudad = new System.Windows.Forms.TextBox();
            this.lblFechaNacimiento = new System.Windows.Forms.Label();
            this.dtpFechaNacimiento = new System.Windows.Forms.DateTimePicker();
            this.lblEstadoCivil = new System.Windows.Forms.Label();
            this.cmbEstadoCivil = new System.Windows.Forms.ComboBox();
            this.lblSexo = new System.Windows.Forms.Label();
            this.rbHombre = new System.Windows.Forms.RadioButton();
            this.rbMujer = new System.Windows.Forms.RadioButton();
            this.picPersona = new System.Windows.Forms.PictureBox();
            this.tabDatosClinicos = new System.Windows.Forms.TabPage();
            this.grpEnfermedad = new System.Windows.Forms.GroupBox();
            this.lblPreguntaEnfermedad = new System.Windows.Forms.Label();
            this.rbEnfermedadSi = new System.Windows.Forms.RadioButton();
            this.rbEnfermedadNo = new System.Windows.Forms.RadioButton();
            this.cmbEnfermedad = new System.Windows.Forms.ComboBox();
            this.grpAlergias = new System.Windows.Forms.GroupBox();
            this.lblPreguntaAlergias = new System.Windows.Forms.Label();
            this.rbAlergiasSi = new System.Windows.Forms.RadioButton();
            this.rbAlergiasNo = new System.Windows.Forms.RadioButton();
            this.cmbAlergias = new System.Windows.Forms.ComboBox();
            this.grpOperado = new System.Windows.Forms.GroupBox();
            this.lblPreguntaOperado = new System.Windows.Forms.Label();
            this.rbOperadoSi = new System.Windows.Forms.RadioButton();
            this.rbOperadoNo = new System.Windows.Forms.RadioButton();
            this.grpEjercicio = new System.Windows.Forms.GroupBox();
            this.lblPreguntaEjercicio = new System.Windows.Forms.Label();
            this.rbEjercicioSi = new System.Windows.Forms.RadioButton();
            this.rbEjercicioNo = new System.Windows.Forms.RadioButton();
            this.grpDepresion = new System.Windows.Forms.GroupBox();
            this.lblPreguntaDepresion = new System.Windows.Forms.Label();
            this.rbDepresionSi = new System.Windows.Forms.RadioButton();
            this.rbDepresionNo = new System.Windows.Forms.RadioButton();
            this.btnRegresar = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabDatosPersonales.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPersona)).BeginInit();
            this.tabDatosClinicos.SuspendLayout();
            this.grpEnfermedad.SuspendLayout();
            this.grpAlergias.SuspendLayout();
            this.grpOperado.SuspendLayout();
            this.grpEjercicio.SuspendLayout();
            this.grpDepresion.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabDatosPersonales);
            this.tabControl1.Controls.Add(this.tabDatosClinicos);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(560, 470);
            this.tabControl1.TabIndex = 1;
            // 
            // tabDatosPersonales
            // 
            this.tabDatosPersonales.Controls.Add(this.lblNombre);
            this.tabDatosPersonales.Controls.Add(this.txtNombre);
            this.tabDatosPersonales.Controls.Add(this.lblApellido);
            this.tabDatosPersonales.Controls.Add(this.txtApellido);
            this.tabDatosPersonales.Controls.Add(this.lblDireccion);
            this.tabDatosPersonales.Controls.Add(this.txtDireccion);
            this.tabDatosPersonales.Controls.Add(this.lblCiudad);
            this.tabDatosPersonales.Controls.Add(this.txtCiudad);
            this.tabDatosPersonales.Controls.Add(this.lblFechaNacimiento);
            this.tabDatosPersonales.Controls.Add(this.dtpFechaNacimiento);
            this.tabDatosPersonales.Controls.Add(this.lblEstadoCivil);
            this.tabDatosPersonales.Controls.Add(this.cmbEstadoCivil);
            this.tabDatosPersonales.Controls.Add(this.lblSexo);
            this.tabDatosPersonales.Controls.Add(this.rbHombre);
            this.tabDatosPersonales.Controls.Add(this.rbMujer);
            this.tabDatosPersonales.Controls.Add(this.picPersona);
            this.tabDatosPersonales.Location = new System.Drawing.Point(4, 22);
            this.tabDatosPersonales.Name = "tabDatosPersonales";
            this.tabDatosPersonales.Padding = new System.Windows.Forms.Padding(3);
            this.tabDatosPersonales.Size = new System.Drawing.Size(552, 444);
            this.tabDatosPersonales.TabIndex = 0;
            this.tabDatosPersonales.Text = "Datos Personales";
            this.tabDatosPersonales.UseVisualStyleBackColor = true;
            // 
            // lblNombre
            // 
            this.lblNombre.Location = new System.Drawing.Point(20, 25);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(90, 23);
            this.lblNombre.TabIndex = 0;
            this.lblNombre.Text = "Nombre:";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(120, 22);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(200, 20);
            this.txtNombre.TabIndex = 1;
            // 
            // lblApellido
            // 
            this.lblApellido.Location = new System.Drawing.Point(20, 60);
            this.lblApellido.Name = "lblApellido";
            this.lblApellido.Size = new System.Drawing.Size(90, 23);
            this.lblApellido.TabIndex = 2;
            this.lblApellido.Text = "Apellido:";
            // 
            // txtApellido
            // 
            this.txtApellido.Location = new System.Drawing.Point(120, 57);
            this.txtApellido.Name = "txtApellido";
            this.txtApellido.Size = new System.Drawing.Size(200, 20);
            this.txtApellido.TabIndex = 3;
            // 
            // lblDireccion
            // 
            this.lblDireccion.Location = new System.Drawing.Point(20, 95);
            this.lblDireccion.Name = "lblDireccion";
            this.lblDireccion.Size = new System.Drawing.Size(90, 23);
            this.lblDireccion.TabIndex = 4;
            this.lblDireccion.Text = "Dirección:";
            // 
            // txtDireccion
            // 
            this.txtDireccion.Location = new System.Drawing.Point(120, 92);
            this.txtDireccion.Name = "txtDireccion";
            this.txtDireccion.Size = new System.Drawing.Size(200, 20);
            this.txtDireccion.TabIndex = 5;
            // 
            // lblCiudad
            // 
            this.lblCiudad.Location = new System.Drawing.Point(20, 130);
            this.lblCiudad.Name = "lblCiudad";
            this.lblCiudad.Size = new System.Drawing.Size(90, 23);
            this.lblCiudad.TabIndex = 6;
            this.lblCiudad.Text = "Ciudad:";
            // 
            // txtCiudad
            // 
            this.txtCiudad.Location = new System.Drawing.Point(120, 127);
            this.txtCiudad.Name = "txtCiudad";
            this.txtCiudad.Size = new System.Drawing.Size(200, 20);
            this.txtCiudad.TabIndex = 7;
            // 
            // lblFechaNacimiento
            // 
            this.lblFechaNacimiento.Location = new System.Drawing.Point(20, 165);
            this.lblFechaNacimiento.Name = "lblFechaNacimiento";
            this.lblFechaNacimiento.Size = new System.Drawing.Size(120, 23);
            this.lblFechaNacimiento.TabIndex = 8;
            this.lblFechaNacimiento.Text = "Fecha de Nacimiento:";
            // 
            // dtpFechaNacimiento
            // 
            this.dtpFechaNacimiento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaNacimiento.Location = new System.Drawing.Point(150, 162);
            this.dtpFechaNacimiento.Name = "dtpFechaNacimiento";
            this.dtpFechaNacimiento.Size = new System.Drawing.Size(170, 20);
            this.dtpFechaNacimiento.TabIndex = 9;
            // 
            // lblEstadoCivil
            // 
            this.lblEstadoCivil.Location = new System.Drawing.Point(20, 200);
            this.lblEstadoCivil.Name = "lblEstadoCivil";
            this.lblEstadoCivil.Size = new System.Drawing.Size(90, 23);
            this.lblEstadoCivil.TabIndex = 10;
            this.lblEstadoCivil.Text = "Estado Civil:";
            // 
            // cmbEstadoCivil
            // 
            this.cmbEstadoCivil.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEstadoCivil.Items.AddRange(new object[] {
            "Soltero",
            "Casado",
            "Divorciado",
            "Viudo"});
            this.cmbEstadoCivil.Location = new System.Drawing.Point(120, 197);
            this.cmbEstadoCivil.Name = "cmbEstadoCivil";
            this.cmbEstadoCivil.Size = new System.Drawing.Size(150, 21);
            this.cmbEstadoCivil.TabIndex = 11;
            // 
            // lblSexo
            // 
            this.lblSexo.Location = new System.Drawing.Point(20, 235);
            this.lblSexo.Name = "lblSexo";
            this.lblSexo.Size = new System.Drawing.Size(60, 23);
            this.lblSexo.TabIndex = 12;
            this.lblSexo.Text = "Sexo:";
            // 
            // rbHombre
            // 
            this.rbHombre.AutoSize = true;
            this.rbHombre.Location = new System.Drawing.Point(120, 236);
            this.rbHombre.Name = "rbHombre";
            this.rbHombre.Size = new System.Drawing.Size(62, 17);
            this.rbHombre.TabIndex = 13;
            this.rbHombre.Text = "Hombre";
            this.rbHombre.UseVisualStyleBackColor = true;
            // 
            // rbMujer
            // 
            this.rbMujer.AutoSize = true;
            this.rbMujer.Location = new System.Drawing.Point(210, 236);
            this.rbMujer.Name = "rbMujer";
            this.rbMujer.Size = new System.Drawing.Size(51, 17);
            this.rbMujer.TabIndex = 14;
            this.rbMujer.Text = "Mujer";
            this.rbMujer.UseVisualStyleBackColor = true;
            // 
            // picPersona
            // 
            this.picPersona.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.picPersona.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picPersona.Image = ((System.Drawing.Image)(resources.GetObject("picPersona.Image")));
            this.picPersona.Location = new System.Drawing.Point(350, 25);
            this.picPersona.Name = "picPersona";
            this.picPersona.Size = new System.Drawing.Size(170, 200);
            this.picPersona.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picPersona.TabIndex = 15;
            this.picPersona.TabStop = false;
            // 
            // tabDatosClinicos
            // 
            this.tabDatosClinicos.Controls.Add(this.grpEnfermedad);
            this.tabDatosClinicos.Controls.Add(this.grpAlergias);
            this.tabDatosClinicos.Controls.Add(this.grpOperado);
            this.tabDatosClinicos.Controls.Add(this.grpEjercicio);
            this.tabDatosClinicos.Controls.Add(this.grpDepresion);
            this.tabDatosClinicos.Location = new System.Drawing.Point(4, 22);
            this.tabDatosClinicos.Name = "tabDatosClinicos";
            this.tabDatosClinicos.Padding = new System.Windows.Forms.Padding(3);
            this.tabDatosClinicos.Size = new System.Drawing.Size(552, 444);
            this.tabDatosClinicos.TabIndex = 1;
            this.tabDatosClinicos.Text = "Datos clínicos";
            this.tabDatosClinicos.UseVisualStyleBackColor = true;
            // 
            // grpEnfermedad
            // 
            this.grpEnfermedad.Controls.Add(this.lblPreguntaEnfermedad);
            this.grpEnfermedad.Controls.Add(this.rbEnfermedadSi);
            this.grpEnfermedad.Controls.Add(this.rbEnfermedadNo);
            this.grpEnfermedad.Controls.Add(this.cmbEnfermedad);
            this.grpEnfermedad.Location = new System.Drawing.Point(15, 15);
            this.grpEnfermedad.Name = "grpEnfermedad";
            this.grpEnfermedad.Size = new System.Drawing.Size(510, 65);
            this.grpEnfermedad.TabIndex = 0;
            this.grpEnfermedad.TabStop = false;
            // 
            // lblPreguntaEnfermedad
            // 
            this.lblPreguntaEnfermedad.Location = new System.Drawing.Point(10, 25);
            this.lblPreguntaEnfermedad.Name = "lblPreguntaEnfermedad";
            this.lblPreguntaEnfermedad.Size = new System.Drawing.Size(210, 30);
            this.lblPreguntaEnfermedad.TabIndex = 0;
            this.lblPreguntaEnfermedad.Text = "¿Padeces de alguna enfermedad?";
            // 
            // rbEnfermedadSi
            // 
            this.rbEnfermedadSi.AutoSize = true;
            this.rbEnfermedadSi.Location = new System.Drawing.Point(225, 30);
            this.rbEnfermedadSi.Name = "rbEnfermedadSi";
            this.rbEnfermedadSi.Size = new System.Drawing.Size(36, 17);
            this.rbEnfermedadSi.TabIndex = 1;
            this.rbEnfermedadSi.Text = "Sí";
            this.rbEnfermedadSi.UseVisualStyleBackColor = true;
            // 
            // rbEnfermedadNo
            // 
            this.rbEnfermedadNo.AutoSize = true;
            this.rbEnfermedadNo.Checked = true;
            this.rbEnfermedadNo.Location = new System.Drawing.Point(280, 30);
            this.rbEnfermedadNo.Name = "rbEnfermedadNo";
            this.rbEnfermedadNo.Size = new System.Drawing.Size(39, 17);
            this.rbEnfermedadNo.TabIndex = 2;
            this.rbEnfermedadNo.TabStop = true;
            this.rbEnfermedadNo.Text = "No";
            this.rbEnfermedadNo.UseVisualStyleBackColor = true;
            // 
            // cmbEnfermedad
            // 
            this.cmbEnfermedad.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEnfermedad.Items.AddRange(new object[] {
            "Ninguna",
            "Diabetes",
            "Hipertensión",
            "Asma",
            "Otra"});
            this.cmbEnfermedad.Location = new System.Drawing.Point(350, 27);
            this.cmbEnfermedad.Name = "cmbEnfermedad";
            this.cmbEnfermedad.Size = new System.Drawing.Size(140, 21);
            this.cmbEnfermedad.TabIndex = 3;
            // 
            // grpAlergias
            // 
            this.grpAlergias.Controls.Add(this.lblPreguntaAlergias);
            this.grpAlergias.Controls.Add(this.rbAlergiasSi);
            this.grpAlergias.Controls.Add(this.rbAlergiasNo);
            this.grpAlergias.Controls.Add(this.cmbAlergias);
            this.grpAlergias.Location = new System.Drawing.Point(15, 90);
            this.grpAlergias.Name = "grpAlergias";
            this.grpAlergias.Size = new System.Drawing.Size(510, 65);
            this.grpAlergias.TabIndex = 1;
            this.grpAlergias.TabStop = false;
            // 
            // lblPreguntaAlergias
            // 
            this.lblPreguntaAlergias.Location = new System.Drawing.Point(10, 25);
            this.lblPreguntaAlergias.Name = "lblPreguntaAlergias";
            this.lblPreguntaAlergias.Size = new System.Drawing.Size(210, 30);
            this.lblPreguntaAlergias.TabIndex = 0;
            this.lblPreguntaAlergias.Text = "¿Tienes alergias?";
            // 
            // rbAlergiasSi
            // 
            this.rbAlergiasSi.AutoSize = true;
            this.rbAlergiasSi.Location = new System.Drawing.Point(225, 30);
            this.rbAlergiasSi.Name = "rbAlergiasSi";
            this.rbAlergiasSi.Size = new System.Drawing.Size(36, 17);
            this.rbAlergiasSi.TabIndex = 1;
            this.rbAlergiasSi.Text = "Sí";
            this.rbAlergiasSi.UseVisualStyleBackColor = true;
            // 
            // rbAlergiasNo
            // 
            this.rbAlergiasNo.AutoSize = true;
            this.rbAlergiasNo.Checked = true;
            this.rbAlergiasNo.Location = new System.Drawing.Point(280, 30);
            this.rbAlergiasNo.Name = "rbAlergiasNo";
            this.rbAlergiasNo.Size = new System.Drawing.Size(39, 17);
            this.rbAlergiasNo.TabIndex = 2;
            this.rbAlergiasNo.TabStop = true;
            this.rbAlergiasNo.Text = "No";
            this.rbAlergiasNo.UseVisualStyleBackColor = true;
            // 
            // cmbAlergias
            // 
            this.cmbAlergias.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAlergias.Items.AddRange(new object[] {
            "Ninguna",
            "Polen",
            "Alimentos",
            "Medicamentos",
            "Otra"});
            this.cmbAlergias.Location = new System.Drawing.Point(350, 27);
            this.cmbAlergias.Name = "cmbAlergias";
            this.cmbAlergias.Size = new System.Drawing.Size(140, 21);
            this.cmbAlergias.TabIndex = 3;
            // 
            // grpOperado
            // 
            this.grpOperado.Controls.Add(this.lblPreguntaOperado);
            this.grpOperado.Controls.Add(this.rbOperadoSi);
            this.grpOperado.Controls.Add(this.rbOperadoNo);
            this.grpOperado.Location = new System.Drawing.Point(15, 165);
            this.grpOperado.Name = "grpOperado";
            this.grpOperado.Size = new System.Drawing.Size(510, 55);
            this.grpOperado.TabIndex = 2;
            this.grpOperado.TabStop = false;
            // 
            // lblPreguntaOperado
            // 
            this.lblPreguntaOperado.Location = new System.Drawing.Point(10, 22);
            this.lblPreguntaOperado.Name = "lblPreguntaOperado";
            this.lblPreguntaOperado.Size = new System.Drawing.Size(210, 23);
            this.lblPreguntaOperado.TabIndex = 0;
            this.lblPreguntaOperado.Text = "¿Alguna vez te han operado?";
            // 
            // rbOperadoSi
            // 
            this.rbOperadoSi.AutoSize = true;
            this.rbOperadoSi.Location = new System.Drawing.Point(225, 22);
            this.rbOperadoSi.Name = "rbOperadoSi";
            this.rbOperadoSi.Size = new System.Drawing.Size(36, 17);
            this.rbOperadoSi.TabIndex = 1;
            this.rbOperadoSi.Text = "Sí";
            this.rbOperadoSi.UseVisualStyleBackColor = true;
            // 
            // rbOperadoNo
            // 
            this.rbOperadoNo.AutoSize = true;
            this.rbOperadoNo.Checked = true;
            this.rbOperadoNo.Location = new System.Drawing.Point(280, 22);
            this.rbOperadoNo.Name = "rbOperadoNo";
            this.rbOperadoNo.Size = new System.Drawing.Size(39, 17);
            this.rbOperadoNo.TabIndex = 2;
            this.rbOperadoNo.TabStop = true;
            this.rbOperadoNo.Text = "No";
            this.rbOperadoNo.UseVisualStyleBackColor = true;
            // 
            // grpEjercicio
            // 
            this.grpEjercicio.Controls.Add(this.lblPreguntaEjercicio);
            this.grpEjercicio.Controls.Add(this.rbEjercicioSi);
            this.grpEjercicio.Controls.Add(this.rbEjercicioNo);
            this.grpEjercicio.Location = new System.Drawing.Point(15, 225);
            this.grpEjercicio.Name = "grpEjercicio";
            this.grpEjercicio.Size = new System.Drawing.Size(510, 55);
            this.grpEjercicio.TabIndex = 3;
            this.grpEjercicio.TabStop = false;
            // 
            // lblPreguntaEjercicio
            // 
            this.lblPreguntaEjercicio.Location = new System.Drawing.Point(10, 22);
            this.lblPreguntaEjercicio.Name = "lblPreguntaEjercicio";
            this.lblPreguntaEjercicio.Size = new System.Drawing.Size(210, 23);
            this.lblPreguntaEjercicio.TabIndex = 0;
            this.lblPreguntaEjercicio.Text = "¿Haces ejercicio?";
            // 
            // rbEjercicioSi
            // 
            this.rbEjercicioSi.AutoSize = true;
            this.rbEjercicioSi.Location = new System.Drawing.Point(225, 22);
            this.rbEjercicioSi.Name = "rbEjercicioSi";
            this.rbEjercicioSi.Size = new System.Drawing.Size(36, 17);
            this.rbEjercicioSi.TabIndex = 1;
            this.rbEjercicioSi.Text = "Sí";
            this.rbEjercicioSi.UseVisualStyleBackColor = true;
            // 
            // rbEjercicioNo
            // 
            this.rbEjercicioNo.AutoSize = true;
            this.rbEjercicioNo.Checked = true;
            this.rbEjercicioNo.Location = new System.Drawing.Point(280, 22);
            this.rbEjercicioNo.Name = "rbEjercicioNo";
            this.rbEjercicioNo.Size = new System.Drawing.Size(39, 17);
            this.rbEjercicioNo.TabIndex = 2;
            this.rbEjercicioNo.TabStop = true;
            this.rbEjercicioNo.Text = "No";
            this.rbEjercicioNo.UseVisualStyleBackColor = true;
            // 
            // grpDepresion
            // 
            this.grpDepresion.Controls.Add(this.lblPreguntaDepresion);
            this.grpDepresion.Controls.Add(this.rbDepresionSi);
            this.grpDepresion.Controls.Add(this.rbDepresionNo);
            this.grpDepresion.Location = new System.Drawing.Point(15, 285);
            this.grpDepresion.Name = "grpDepresion";
            this.grpDepresion.Size = new System.Drawing.Size(510, 55);
            this.grpDepresion.TabIndex = 4;
            this.grpDepresion.TabStop = false;
            // 
            // lblPreguntaDepresion
            // 
            this.lblPreguntaDepresion.Location = new System.Drawing.Point(10, 22);
            this.lblPreguntaDepresion.Name = "lblPreguntaDepresion";
            this.lblPreguntaDepresion.Size = new System.Drawing.Size(210, 23);
            this.lblPreguntaDepresion.TabIndex = 0;
            this.lblPreguntaDepresion.Text = "¿Padeces de depresión?";
            // 
            // rbDepresionSi
            // 
            this.rbDepresionSi.AutoSize = true;
            this.rbDepresionSi.Location = new System.Drawing.Point(225, 22);
            this.rbDepresionSi.Name = "rbDepresionSi";
            this.rbDepresionSi.Size = new System.Drawing.Size(36, 17);
            this.rbDepresionSi.TabIndex = 1;
            this.rbDepresionSi.Text = "Sí";
            this.rbDepresionSi.UseVisualStyleBackColor = true;
            // 
            // rbDepresionNo
            // 
            this.rbDepresionNo.AutoSize = true;
            this.rbDepresionNo.Checked = true;
            this.rbDepresionNo.Location = new System.Drawing.Point(280, 22);
            this.rbDepresionNo.Name = "rbDepresionNo";
            this.rbDepresionNo.Size = new System.Drawing.Size(39, 17);
            this.rbDepresionNo.TabIndex = 2;
            this.rbDepresionNo.TabStop = true;
            this.rbDepresionNo.Text = "No";
            this.rbDepresionNo.UseVisualStyleBackColor = true;
            // 
            // btnRegresar
            // 
            this.btnRegresar.Location = new System.Drawing.Point(230, 490);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(120, 35);
            this.btnRegresar.TabIndex = 0;
            this.btnRegresar.Text = "Regresar";
            this.btnRegresar.UseVisualStyleBackColor = true;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // FormInformacionPersonal
            // 
            this.ClientSize = new System.Drawing.Size(584, 540);
            this.Controls.Add(this.btnRegresar);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FormInformacionPersonal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Información personal";
            this.tabControl1.ResumeLayout(false);
            this.tabDatosPersonales.ResumeLayout(false);
            this.tabDatosPersonales.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPersona)).EndInit();
            this.tabDatosClinicos.ResumeLayout(false);
            this.grpEnfermedad.ResumeLayout(false);
            this.grpEnfermedad.PerformLayout();
            this.grpAlergias.ResumeLayout(false);
            this.grpAlergias.PerformLayout();
            this.grpOperado.ResumeLayout(false);
            this.grpOperado.PerformLayout();
            this.grpEjercicio.ResumeLayout(false);
            this.grpEjercicio.PerformLayout();
            this.grpDepresion.ResumeLayout(false);
            this.grpDepresion.PerformLayout();
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabDatosPersonales;
        private System.Windows.Forms.TabPage tabDatosClinicos;
        private System.Windows.Forms.Button btnRegresar;

        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label lblApellido;
        private System.Windows.Forms.TextBox txtApellido;
        private System.Windows.Forms.Label lblDireccion;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.Label lblCiudad;
        private System.Windows.Forms.TextBox txtCiudad;
        private System.Windows.Forms.Label lblFechaNacimiento;
        private System.Windows.Forms.DateTimePicker dtpFechaNacimiento;
        private System.Windows.Forms.Label lblEstadoCivil;
        private System.Windows.Forms.ComboBox cmbEstadoCivil;
        private System.Windows.Forms.Label lblSexo;
        private System.Windows.Forms.RadioButton rbHombre;
        private System.Windows.Forms.RadioButton rbMujer;
        private System.Windows.Forms.PictureBox picPersona;

        private System.Windows.Forms.GroupBox grpEnfermedad;
        private System.Windows.Forms.Label lblPreguntaEnfermedad;
        private System.Windows.Forms.RadioButton rbEnfermedadSi;
        private System.Windows.Forms.RadioButton rbEnfermedadNo;
        private System.Windows.Forms.ComboBox cmbEnfermedad;

        private System.Windows.Forms.GroupBox grpAlergias;
        private System.Windows.Forms.Label lblPreguntaAlergias;
        private System.Windows.Forms.RadioButton rbAlergiasSi;
        private System.Windows.Forms.RadioButton rbAlergiasNo;
        private System.Windows.Forms.ComboBox cmbAlergias;

        private System.Windows.Forms.GroupBox grpOperado;
        private System.Windows.Forms.Label lblPreguntaOperado;
        private System.Windows.Forms.RadioButton rbOperadoSi;
        private System.Windows.Forms.RadioButton rbOperadoNo;

        private System.Windows.Forms.GroupBox grpEjercicio;
        private System.Windows.Forms.Label lblPreguntaEjercicio;
        private System.Windows.Forms.RadioButton rbEjercicioSi;
        private System.Windows.Forms.RadioButton rbEjercicioNo;

        private System.Windows.Forms.GroupBox grpDepresion;
        private System.Windows.Forms.Label lblPreguntaDepresion;
        private System.Windows.Forms.RadioButton rbDepresionSi;
        private System.Windows.Forms.RadioButton rbDepresionNo;
    }
}
