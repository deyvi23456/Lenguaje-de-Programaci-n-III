using System;
using System.Windows.Forms;

namespace Actividad2
{
    public partial class FormInformacionPersonal : Form
    {
        public FormInformacionPersonal()
        {
            InitializeComponent();
            // Recuerda asignar aquí el ícono de la universidad, por ejemplo:
            // this.Icon = new System.Drawing.Icon("logo.ico");
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            FormMenu menu = new FormMenu();
            menu.Show();
            this.Close();
        }
    }
}
