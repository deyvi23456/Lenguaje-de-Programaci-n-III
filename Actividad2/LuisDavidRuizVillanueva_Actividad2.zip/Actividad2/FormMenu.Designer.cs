namespace Actividad2
{
    partial class FormMenu
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMenu));
            this.panelMenu = new System.Windows.Forms.Panel();
            this.lnkSaludo = new System.Windows.Forms.LinkLabel();
            this.lnkDatosPersonales = new System.Windows.Forms.LinkLabel();
            this.lnkOperaciones = new System.Windows.Forms.LinkLabel();
            this.lnkSalir = new System.Windows.Forms.LinkLabel();
            this.picPortada = new System.Windows.Forms.PictureBox();
            this.panelMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPortada)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panelMenu.Controls.Add(this.lnkSaludo);
            this.panelMenu.Controls.Add(this.lnkDatosPersonales);
            this.panelMenu.Controls.Add(this.lnkOperaciones);
            this.panelMenu.Controls.Add(this.lnkSalir);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(180, 450);
            this.panelMenu.TabIndex = 1;
            // 
            // lnkSaludo
            // 
            this.lnkSaludo.AutoSize = true;
            this.lnkSaludo.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lnkSaludo.LinkColor = System.Drawing.Color.Black;
            this.lnkSaludo.Location = new System.Drawing.Point(45, 40);
            this.lnkSaludo.Name = "lnkSaludo";
            this.lnkSaludo.Size = new System.Drawing.Size(55, 20);
            this.lnkSaludo.TabIndex = 0;
            this.lnkSaludo.TabStop = true;
            this.lnkSaludo.Text = "Saludo";
            this.lnkSaludo.Click += new System.EventHandler(this.lnkSaludo_Click);
            // 
            // lnkDatosPersonales
            // 
            this.lnkDatosPersonales.AutoSize = true;
            this.lnkDatosPersonales.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lnkDatosPersonales.LinkColor = System.Drawing.Color.Black;
            this.lnkDatosPersonales.Location = new System.Drawing.Point(15, 80);
            this.lnkDatosPersonales.Name = "lnkDatosPersonales";
            this.lnkDatosPersonales.Size = new System.Drawing.Size(121, 20);
            this.lnkDatosPersonales.TabIndex = 1;
            this.lnkDatosPersonales.TabStop = true;
            this.lnkDatosPersonales.Text = "Datos Personales";
            this.lnkDatosPersonales.Click += new System.EventHandler(this.lnkDatosPersonales_Click);
            // 
            // lnkOperaciones
            // 
            this.lnkOperaciones.AutoSize = true;
            this.lnkOperaciones.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lnkOperaciones.LinkColor = System.Drawing.Color.Black;
            this.lnkOperaciones.Location = new System.Drawing.Point(10, 120);
            this.lnkOperaciones.Name = "lnkOperaciones";
            this.lnkOperaciones.Size = new System.Drawing.Size(144, 20);
            this.lnkOperaciones.TabIndex = 2;
            this.lnkOperaciones.TabStop = true;
            this.lnkOperaciones.Text = "Operaciones Basicas";
            this.lnkOperaciones.Click += new System.EventHandler(this.lnkOperaciones_Click);
            // 
            // lnkSalir
            // 
            this.lnkSalir.AutoSize = true;
            this.lnkSalir.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lnkSalir.LinkColor = System.Drawing.Color.Black;
            this.lnkSalir.Location = new System.Drawing.Point(65, 160);
            this.lnkSalir.Name = "lnkSalir";
            this.lnkSalir.Size = new System.Drawing.Size(38, 20);
            this.lnkSalir.TabIndex = 3;
            this.lnkSalir.TabStop = true;
            this.lnkSalir.Text = "Salir";
            this.lnkSalir.Click += new System.EventHandler(this.lnkSalir_Click);
            // 
            // picPortada
            // 
            this.picPortada.BackColor = System.Drawing.Color.WhiteSmoke;
            this.picPortada.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picPortada.Image = ((System.Drawing.Image)(resources.GetObject("picPortada.Image")));
            this.picPortada.Location = new System.Drawing.Point(180, 0);
            this.picPortada.Name = "picPortada";
            this.picPortada.Size = new System.Drawing.Size(470, 450);
            this.picPortada.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picPortada.TabIndex = 0;
            this.picPortada.TabStop = false;
            // 
            // FormMenu
            // 
            this.ClientSize = new System.Drawing.Size(650, 450);
            this.Controls.Add(this.picPortada);
            this.Controls.Add(this.panelMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMenu_FormClosing);
            this.panelMenu.ResumeLayout(false);
            this.panelMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPortada)).EndInit();
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.LinkLabel lnkSaludo;
        private System.Windows.Forms.LinkLabel lnkDatosPersonales;
        private System.Windows.Forms.LinkLabel lnkOperaciones;
        private System.Windows.Forms.LinkLabel lnkSalir;
        private System.Windows.Forms.PictureBox picPortada;
    }
}
