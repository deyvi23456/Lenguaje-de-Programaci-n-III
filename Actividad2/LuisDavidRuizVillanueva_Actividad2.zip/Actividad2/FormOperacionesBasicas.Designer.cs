namespace Actividad2
{
    partial class FormOperacionesBasicas
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormOperacionesBasicas));
            this.lblExplicacion = new System.Windows.Forms.Label();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.lblNum3 = new System.Windows.Forms.Label();
            this.txtNum3 = new System.Windows.Forms.TextBox();
            this.lblNum4 = new System.Windows.Forms.Label();
            this.txtNum4 = new System.Windows.Forms.TextBox();
            this.lblNum5 = new System.Windows.Forms.Label();
            this.txtNum5 = new System.Windows.Forms.TextBox();
            this.lblNum6 = new System.Windows.Forms.Label();
            this.txtNum6 = new System.Windows.Forms.TextBox();
            this.lblResultado = new System.Windows.Forms.Label();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.btnSuma = new System.Windows.Forms.Button();
            this.btnResta = new System.Windows.Forms.Button();
            this.btnMultiplicacion = new System.Windows.Forms.Button();
            this.btnDivision = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnRegresar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblExplicacion
            // 
            this.lblExplicacion.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblExplicacion.Location = new System.Drawing.Point(20, 15);
            this.lblExplicacion.Name = "lblExplicacion";
            this.lblExplicacion.Size = new System.Drawing.Size(430, 45);
            this.lblExplicacion.TabIndex = 0;
            this.lblExplicacion.Text = "Ingresa 6 números y elige una operación. El resultado se calculará usando todos l" +
    "os números capturados.";
            // 
            // lblNum1
            // 
            this.lblNum1.Location = new System.Drawing.Point(20, 70);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(90, 23);
            this.lblNum1.TabIndex = 1;
            this.lblNum1.Text = "Número 1:";
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(115, 67);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(120, 20);
            this.txtNum1.TabIndex = 2;
            // 
            // lblNum2
            // 
            this.lblNum2.Location = new System.Drawing.Point(20, 100);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(90, 23);
            this.lblNum2.TabIndex = 3;
            this.lblNum2.Text = "Número 2:";
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(115, 97);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(120, 20);
            this.txtNum2.TabIndex = 4;
            // 
            // lblNum3
            // 
            this.lblNum3.Location = new System.Drawing.Point(20, 130);
            this.lblNum3.Name = "lblNum3";
            this.lblNum3.Size = new System.Drawing.Size(90, 23);
            this.lblNum3.TabIndex = 5;
            this.lblNum3.Text = "Número 3:";
            // 
            // txtNum3
            // 
            this.txtNum3.Location = new System.Drawing.Point(115, 127);
            this.txtNum3.Name = "txtNum3";
            this.txtNum3.Size = new System.Drawing.Size(120, 20);
            this.txtNum3.TabIndex = 6;
            // 
            // lblNum4
            // 
            this.lblNum4.Location = new System.Drawing.Point(20, 160);
            this.lblNum4.Name = "lblNum4";
            this.lblNum4.Size = new System.Drawing.Size(90, 23);
            this.lblNum4.TabIndex = 7;
            this.lblNum4.Text = "Número 4:";
            // 
            // txtNum4
            // 
            this.txtNum4.Location = new System.Drawing.Point(115, 157);
            this.txtNum4.Name = "txtNum4";
            this.txtNum4.Size = new System.Drawing.Size(120, 20);
            this.txtNum4.TabIndex = 8;
            // 
            // lblNum5
            // 
            this.lblNum5.Location = new System.Drawing.Point(20, 190);
            this.lblNum5.Name = "lblNum5";
            this.lblNum5.Size = new System.Drawing.Size(90, 23);
            this.lblNum5.TabIndex = 9;
            this.lblNum5.Text = "Número 5:";
            // 
            // txtNum5
            // 
            this.txtNum5.Location = new System.Drawing.Point(115, 187);
            this.txtNum5.Name = "txtNum5";
            this.txtNum5.Size = new System.Drawing.Size(120, 20);
            this.txtNum5.TabIndex = 10;
            // 
            // lblNum6
            // 
            this.lblNum6.Location = new System.Drawing.Point(20, 220);
            this.lblNum6.Name = "lblNum6";
            this.lblNum6.Size = new System.Drawing.Size(90, 23);
            this.lblNum6.TabIndex = 11;
            this.lblNum6.Text = "Número 6:";
            // 
            // txtNum6
            // 
            this.txtNum6.Location = new System.Drawing.Point(115, 217);
            this.txtNum6.Name = "txtNum6";
            this.txtNum6.Size = new System.Drawing.Size(120, 20);
            this.txtNum6.TabIndex = 12;
            // 
            // lblResultado
            // 
            this.lblResultado.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblResultado.Location = new System.Drawing.Point(280, 70);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(90, 23);
            this.lblResultado.TabIndex = 13;
            this.lblResultado.Text = "Resultado:";
            // 
            // txtResultado
            // 
            this.txtResultado.Location = new System.Drawing.Point(280, 100);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.ReadOnly = true;
            this.txtResultado.Size = new System.Drawing.Size(160, 20);
            this.txtResultado.TabIndex = 14;
            // 
            // btnSuma
            // 
            this.btnSuma.Location = new System.Drawing.Point(20, 270);
            this.btnSuma.Name = "btnSuma";
            this.btnSuma.Size = new System.Drawing.Size(120, 32);
            this.btnSuma.TabIndex = 15;
            this.btnSuma.Text = "Suma";
            this.btnSuma.UseVisualStyleBackColor = true;
            this.btnSuma.Click += new System.EventHandler(this.btnSuma_Click);
            // 
            // btnResta
            // 
            this.btnResta.Location = new System.Drawing.Point(160, 270);
            this.btnResta.Name = "btnResta";
            this.btnResta.Size = new System.Drawing.Size(120, 32);
            this.btnResta.TabIndex = 16;
            this.btnResta.Text = "Resta";
            this.btnResta.UseVisualStyleBackColor = true;
            this.btnResta.Click += new System.EventHandler(this.btnResta_Click);
            // 
            // btnMultiplicacion
            // 
            this.btnMultiplicacion.Location = new System.Drawing.Point(300, 270);
            this.btnMultiplicacion.Name = "btnMultiplicacion";
            this.btnMultiplicacion.Size = new System.Drawing.Size(140, 32);
            this.btnMultiplicacion.TabIndex = 17;
            this.btnMultiplicacion.Text = "Multiplicación";
            this.btnMultiplicacion.UseVisualStyleBackColor = true;
            this.btnMultiplicacion.Click += new System.EventHandler(this.btnMultiplicacion_Click);
            // 
            // btnDivision
            // 
            this.btnDivision.Location = new System.Drawing.Point(20, 315);
            this.btnDivision.Name = "btnDivision";
            this.btnDivision.Size = new System.Drawing.Size(120, 32);
            this.btnDivision.TabIndex = 18;
            this.btnDivision.Text = "División";
            this.btnDivision.UseVisualStyleBackColor = true;
            this.btnDivision.Click += new System.EventHandler(this.btnDivision_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(160, 315);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(120, 32);
            this.btnLimpiar.TabIndex = 19;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // btnRegresar
            // 
            this.btnRegresar.Location = new System.Drawing.Point(300, 315);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(140, 32);
            this.btnRegresar.TabIndex = 20;
            this.btnRegresar.Text = "Regresar";
            this.btnRegresar.UseVisualStyleBackColor = true;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // FormOperacionesBasicas
            // 
            this.ClientSize = new System.Drawing.Size(470, 370);
            this.Controls.Add(this.lblExplicacion);
            this.Controls.Add(this.lblNum1);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.lblNum3);
            this.Controls.Add(this.txtNum3);
            this.Controls.Add(this.lblNum4);
            this.Controls.Add(this.txtNum4);
            this.Controls.Add(this.lblNum5);
            this.Controls.Add(this.txtNum5);
            this.Controls.Add(this.lblNum6);
            this.Controls.Add(this.txtNum6);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.btnSuma);
            this.Controls.Add(this.btnResta);
            this.Controls.Add(this.btnMultiplicacion);
            this.Controls.Add(this.btnDivision);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnRegresar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FormOperacionesBasicas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Operaciones Básicas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Label lblExplicacion;
        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.Label lblNum3;
        private System.Windows.Forms.TextBox txtNum3;
        private System.Windows.Forms.Label lblNum4;
        private System.Windows.Forms.TextBox txtNum4;
        private System.Windows.Forms.Label lblNum5;
        private System.Windows.Forms.TextBox txtNum5;
        private System.Windows.Forms.Label lblNum6;
        private System.Windows.Forms.TextBox txtNum6;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Button btnSuma;
        private System.Windows.Forms.Button btnResta;
        private System.Windows.Forms.Button btnMultiplicacion;
        private System.Windows.Forms.Button btnDivision;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnRegresar;
    }
}
