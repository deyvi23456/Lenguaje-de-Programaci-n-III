using System;
using System.Windows.Forms;

namespace Actividad2
{
    public partial class FormOperacionesBasicas : Form
    {
        public FormOperacionesBasicas()
        {
            InitializeComponent();
            // Recuerda asignar aquí el ícono de la universidad, por ejemplo:
            // this.Icon = new System.Drawing.Icon("logo.ico");
        }

        // Lee los 6 textbox y los convierte en un arreglo de double.
        // Regresa null y muestra un mensaje si algún campo está vacío o no es numérico.
        private double[] ObtenerNumeros()
        {
            TextBox[] cajas = { txtNum1, txtNum2, txtNum3, txtNum4, txtNum5, txtNum6 };
            double[] numeros = new double[6];

            for (int i = 0; i < cajas.Length; i++)
            {
                if (!double.TryParse(cajas[i].Text, out numeros[i]))
                {
                    MessageBox.Show("Por favor ingresa los 6 números correctamente.", "Datos inválidos",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return null;
                }
            }
            return numeros;
        }

        private void btnSuma_Click(object sender, EventArgs e)
        {
            double[] n = ObtenerNumeros();
            if (n == null) return;

            double resultado = 0;
            foreach (double valor in n) resultado += valor;
            txtResultado.Text = resultado.ToString();
        }

        private void btnResta_Click(object sender, EventArgs e)
        {
            double[] n = ObtenerNumeros();
            if (n == null) return;

            double resultado = n[0];
            for (int i = 1; i < n.Length; i++) resultado -= n[i];
            txtResultado.Text = resultado.ToString();
        }

        private void btnMultiplicacion_Click(object sender, EventArgs e)
        {
            double[] n = ObtenerNumeros();
            if (n == null) return;

            double resultado = 1;
            foreach (double valor in n) resultado *= valor;
            txtResultado.Text = resultado.ToString();
        }

        private void btnDivision_Click(object sender, EventArgs e)
        {
            double[] n = ObtenerNumeros();
            if (n == null) return;

            double resultado = n[0];
            for (int i = 1; i < n.Length; i++)
            {
                if (n[i] == 0)
                {
                    MessageBox.Show("No es posible dividir entre cero.", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                resultado /= n[i];
            }
            txtResultado.Text = resultado.ToString("0.####");
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtNum3.Clear();
            txtNum4.Clear();
            txtNum5.Clear();
            txtNum6.Clear();
            txtResultado.Clear();
            txtNum1.Focus();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            FormMenu menu = new FormMenu();
            menu.Show();
            this.Close();
        }
    }
}
