using System;
using System.Windows.Forms;

namespace Actividad2
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal de la aplicación.
        /// Inicia mostrando el formulario de Ingreso (contraseña).
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormIngreso());
        }
    }
}
