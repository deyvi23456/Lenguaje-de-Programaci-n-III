using System;
using System.Windows.Forms;

namespace Actividad2
{
    public partial class FormMenu : Form
    {
        public FormMenu()
        {
            InitializeComponent();
            // Recuerda asignar aquí el ícono de la universidad, por ejemplo:
            // this.Icon = new System.Drawing.Icon("logo.ico");
        }

        private void lnkSaludo_Click(object sender, EventArgs e)
        {
            FormSaludo formSaludo = new FormSaludo();
            formSaludo.Show();
            this.Hide();
        }

        private void lnkDatosPersonales_Click(object sender, EventArgs e)
        {
            FormInformacionPersonal formDatos = new FormInformacionPersonal();
            formDatos.Show();
            this.Hide();
        }

        private void lnkOperaciones_Click(object sender, EventArgs e)
        {
            FormOperacionesBasicas formOperaciones = new FormOperacionesBasicas();
            formOperaciones.Show();
            this.Hide();
        }

        private void lnkSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Si el usuario cierra el formulario Menú con la "X", cerramos toda la aplicación
        private void FormMenu_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
