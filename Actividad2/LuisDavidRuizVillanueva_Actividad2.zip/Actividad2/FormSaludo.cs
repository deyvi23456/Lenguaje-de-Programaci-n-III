using System;
using System.Windows.Forms;

namespace Actividad2
{
    public partial class FormSaludo : Form
    {
        public FormSaludo()
        {
            InitializeComponent();
            // Recuerda asignar aquí el ícono de la universidad, por ejemplo:
            // this.Icon = new System.Drawing.Icon("logo.ico");
        }

        private void btnSaludar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("Por favor ingresa tu nombre.", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            MessageBox.Show($"Hola {txtNombre.Text}, ¿Qué tal va tu día?", "Saludo",
                MessageBoxButtons.OK, MessageBoxIcon.None);
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            FormMenu menu = new FormMenu();
            menu.Show();
            this.Close();
        }
    }
}
