using System;
using System.Windows.Forms;

namespace Actividad2
{
    public partial class FormIngreso : Form
    {
        // Cambia esta contraseña por la que tú quieras usar
        private const string CONTRASENA_CORRECTA = "1234";

        public FormIngreso()
        {
            InitializeComponent();
            // Recuerda asignar aquí el ícono de la universidad, por ejemplo:
            // this.Icon = new System.Drawing.Icon("logo.ico");
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            if (txtContrasena.Text == CONTRASENA_CORRECTA)
            {
                FormMenu menu = new FormMenu();
                menu.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Contraseña incorrecta, intenta de nuevo.", "Acceso denegado",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtContrasena.Clear();
                txtContrasena.Focus();
            }
        }
    }
}
